// Função para exibir as iniciais do usuário
function createUserIcon(name) {
    const userIcon = document.getElementById("user-icon");

    const initials = name
        .split(" ")
        .map(word => word[0])
        .join("");

    userIcon.textContent = initials;
    userIcon.style.display = "flex"; // Torna o ícone visível
}

// Função para exibir o botão de logout com efeito cascata
function showLogout() {
    const logoutContainer = document.getElementById("logout-container");

    // Exibe o botão de logout com efeito de cascata
    logoutContainer.style.display = 'block';

    // Atrasar a opacidade para dar o efeito de cascata
    setTimeout(function() {
        logoutContainer.style.opacity = 1;
        logoutContainer.style.transform = 'translateY(10px)'; // Leve translação para baixo
    }, 10); // Espera 10ms para iniciar o efeito de transição
}

// Função para verificar se o usuário está logado
// Função para verificar se o usuário está logado
// Função para verificar se o usuário está logado
async function checkUserLogin() {
    const response = await fetch("/user", { method: "GET" });
    const data = await response.json();

    const loginLinkContainer = document.getElementById("loginav");
    const userIcon = document.getElementById("user-icon");

    if (data.success) {
        // Usuário logado, oculta o link de login e exibe o ícone do usuário
        loginLinkContainer.style.display = 'none';
        userIcon.style.display = 'flex'; // Torna o ícone do usuário visível
        createUserIcon(data.name); // Exibe as iniciais do usuário
    } else {
        // Usuário não logado, exibe o link de login
        loginLinkContainer.style.display = 'block';
        userIcon.style.display = 'none'; // Esconde o ícone do usuário
    }
}

// Função para exibir o nome do usuário
async function displayUserName() {
    try {
        const response = await fetch("/user", { method: "GET" });
        const data = await response.json();

        if (data.success) {
            const userNameContainer = document.getElementById("user-name-container");
            const userNameElement = document.getElementById("user-name");

            userNameElement.textContent = data.name;  // Atualiza o nome do usuário
            userNameContainer.style.display = "block";  // Torna a div visível
        } else {
            console.log('Erro ao carregar o nome do usuário: ', data.message);
        }
    } catch (error) {
        console.error('Erro ao acessar a rota /user:', error);
    }
}


// Verifica se o usuário está logado ao carregar a página
window.onload = displayUserName;


// Verifica o login ao carregar a página
window.onload = checkUserLogin;

// Verifica o login ao carregar a página
window.onload = checkUserLogin;


// Função para realizar o logout
async function logout() {
    await fetch("/logout", { method: "GET" });
    window.location.reload(); // Recarrega a página após o logout
}

// Verifica o login ao carregar a página
window.onload = checkUserLogin;
